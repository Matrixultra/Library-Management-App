-- ============================================================
-- Library Management System - Database Schema
-- Target: MySQL 8.0+
-- ============================================================

CREATE DATABASE IF NOT EXISTS library_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE library_db;

-- ------------------------------------------------------------
-- Table: books
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS books (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    isbn        VARCHAR(20)  NOT NULL UNIQUE,
    title       VARCHAR(255) NOT NULL,
    author      VARCHAR(255) NOT NULL,
    genre       VARCHAR(100),
    year        INT,
    quantity    INT NOT NULL DEFAULT 0,
    available   INT NOT NULL DEFAULT 0,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_quantity_nonneg CHECK (quantity >= 0),
    CONSTRAINT chk_available_range CHECK (available >= 0 AND available <= quantity)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: members
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS members (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(255) NOT NULL,
    email       VARCHAR(255) NOT NULL UNIQUE,
    phone       VARCHAR(20),
    address     VARCHAR(255),
    status      ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    joined_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: transactions  (borrow / return records)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS transactions (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    book_id       INT NOT NULL,
    member_id     INT NOT NULL,
    borrow_date   DATE NOT NULL,
    due_date      DATE NOT NULL,
    return_date   DATE NULL,
    status        ENUM('BORROWED', 'RETURNED') NOT NULL DEFAULT 'BORROWED',
    CONSTRAINT fk_trans_book   FOREIGN KEY (book_id)   REFERENCES books(id)   ON DELETE CASCADE,
    CONSTRAINT fk_trans_member FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_books_title  ON books(title);
CREATE INDEX idx_books_author ON books(author);
CREATE INDEX idx_trans_status ON transactions(status);

-- ------------------------------------------------------------
-- Sample seed data (optional - comment out if not needed)
-- ------------------------------------------------------------
INSERT INTO books (isbn, title, author, genre, year, quantity, available) VALUES
('978-0-13-468599-1', 'Effective Java', 'Joshua Bloch', 'Programming', 2018, 6, 6),
('978-0-262-03384-8', 'Introduction to Algorithms', 'Thomas Cormen', 'Computer Science', 2009, 4, 4),
('978-0-13-235088-4', 'Clean Code', 'Robert Martin', 'Programming', 2008, 5, 5),
('978-0-7432-7356-5', 'The Great Gatsby', 'F. Scott Fitzgerald', 'Fiction', 1925, 3, 3);

INSERT INTO members (name, email, phone, address, status) VALUES
('Alice Johnson', 'alice@email.com', '9876543210', '12 Park Ave', 'ACTIVE'),
('Bob Wilson', 'bob@email.com', '8765432109', '34 Oak St', 'ACTIVE'),
('Carol Davis', 'carol@email.com', '7654321098', '56 Elm St', 'INACTIVE');
