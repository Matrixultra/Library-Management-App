package com.library.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BookTest {

    @Test
    void constructor_setsAvailableEqualToQuantity() {
        Book book = new Book("978-0-13-468599-1", "Effective Java", "Joshua Bloch", "Programming", 2018, 6);
        assertEquals(6, book.getQuantity());
        assertEquals(6, book.getAvailable());
    }

    @Test
    void isAvailable_trueWhenCopiesRemain() {
        Book book = new Book("isbn", "Title", "Author", "Genre", 2020, 3);
        assertTrue(book.isAvailable());
    }

    @Test
    void isAvailable_falseWhenNoCopiesRemain() {
        Book book = new Book("isbn", "Title", "Author", "Genre", 2020, 3);
        book.setAvailable(0);
        assertFalse(book.isAvailable());
    }

    @Test
    void toString_includesTitleAuthorAndYear() {
        Book book = new Book("isbn", "Clean Code", "Robert Martin", "Programming", 2008, 2);
        String str = book.toString();
        assertTrue(str.contains("Clean Code"));
        assertTrue(str.contains("Robert Martin"));
        assertTrue(str.contains("2008"));
    }
}
