package com.library.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class TransactionTest {

    @Test
    void isOverdue_falseWhenDueDateInFuture() {
        Transaction t = new Transaction(1, 1, LocalDate.now(), LocalDate.now().plusDays(5));
        assertFalse(t.isOverdue());
        assertEquals(0, t.daysOverdue());
    }

    @Test
    void isOverdue_trueWhenPastDueAndStillBorrowed() {
        Transaction t = new Transaction(1, 1, LocalDate.now().minusDays(10), LocalDate.now().minusDays(3));
        assertTrue(t.isOverdue());
        assertEquals(3, t.daysOverdue());
    }

    @Test
    void isOverdue_falseOnceReturned() {
        Transaction t = new Transaction(1, 1, LocalDate.now().minusDays(10), LocalDate.now().minusDays(3));
        t.setStatus(Transaction.Status.RETURNED);
        assertFalse(t.isOverdue());
        assertEquals(0, t.daysOverdue());
    }

    @Test
    void isOverdue_falseWhenDueToday() {
        Transaction t = new Transaction(1, 1, LocalDate.now().minusDays(14), LocalDate.now());
        assertFalse(t.isOverdue());
    }
}
