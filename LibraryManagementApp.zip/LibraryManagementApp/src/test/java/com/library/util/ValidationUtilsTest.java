package com.library.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ValidationUtilsTest {

    @Test
    void requireNonBlank_throwsOnNullOrEmpty() {
        assertThrows(IllegalArgumentException.class, () -> ValidationUtils.requireNonBlank(null, "Title"));
        assertThrows(IllegalArgumentException.class, () -> ValidationUtils.requireNonBlank("   ", "Title"));
    }

    @Test
    void requireNonBlank_acceptsNonEmptyValue() {
        assertDoesNotThrow(() -> ValidationUtils.requireNonBlank("Clean Code", "Title"));
    }

    @Test
    void validateIsbn_acceptsValidIsbn13() {
        assertDoesNotThrow(() -> ValidationUtils.validateIsbn("978-0-13-468599-1"));
    }

    @Test
    void validateIsbn_rejectsGarbage() {
        assertThrows(IllegalArgumentException.class, () -> ValidationUtils.validateIsbn("not-an-isbn!!"));
    }

    @Test
    void validateIsbn_rejectsBlank() {
        assertThrows(IllegalArgumentException.class, () -> ValidationUtils.validateIsbn(""));
    }

    @Test
    void validateEmail_acceptsWellFormedAddress() {
        assertDoesNotThrow(() -> ValidationUtils.validateEmail("alice@example.com"));
    }

    @Test
    void validateEmail_rejectsMissingAtSign() {
        assertThrows(IllegalArgumentException.class, () -> ValidationUtils.validateEmail("alice-example.com"));
    }

    @Test
    void validatePhone_allowsBlankSinceOptional() {
        assertDoesNotThrow(() -> ValidationUtils.validatePhone(null));
        assertDoesNotThrow(() -> ValidationUtils.validatePhone(""));
    }

    @Test
    void validatePhone_rejectsLetters() {
        assertThrows(IllegalArgumentException.class, () -> ValidationUtils.validatePhone("call-me-maybe"));
    }

    @Test
    void validateYear_rejectsTooOldOrFuture() {
        assertThrows(IllegalArgumentException.class, () -> ValidationUtils.validateYear(1000));
        assertThrows(IllegalArgumentException.class, () -> ValidationUtils.validateYear(3000));
    }

    @Test
    void validateYear_acceptsReasonableYear() {
        assertDoesNotThrow(() -> ValidationUtils.validateYear(2018));
    }

    @Test
    void validatePositive_rejectsZeroAndNegative() {
        assertThrows(IllegalArgumentException.class, () -> ValidationUtils.validatePositive(0, "Quantity"));
        assertThrows(IllegalArgumentException.class, () -> ValidationUtils.validatePositive(-3, "Quantity"));
    }

    @Test
    void validateNonNegative_rejectsNegativeOnly() {
        assertThrows(IllegalArgumentException.class, () -> ValidationUtils.validateNonNegative(-1, "Available"));
        assertDoesNotThrow(() -> ValidationUtils.validateNonNegative(0, "Available"));
    }
}
