package com.library;

import com.library.gui.MainApp;

/**
 * Plain entry point that hands off to the JavaFX {@link MainApp}.
 * Having a non-Application main class avoids JavaFX module-path
 * issues when running the packaged JAR directly with `java -jar`.
 */
public class Main {
    public static void main(String[] args) {
        MainApp.main(args);
    }
}
