package com.library.dao;

import com.library.model.Transaction;
import com.library.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Data access object for borrow/return {@link Transaction} records.
 * Queries join against books and members to populate display-only
 * fields (book title, member name) in a single round trip.
 */
public class TransactionDAO {

    private static final String SELECT_BASE =
            "SELECT t.*, b.title AS book_title, m.name AS member_name "
                    + "FROM transactions t "
                    + "JOIN books b ON t.book_id = b.id "
                    + "JOIN members m ON t.member_id = m.id ";

    private Connection getConnection() {
        return DatabaseConnection.getInstance().getConnection();
    }

    public boolean addTransaction(Transaction t) {
        String sql = "INSERT INTO transactions (book_id, member_id, borrow_date, due_date, status) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, t.getBookId());
            stmt.setInt(2, t.getMemberId());
            stmt.setDate(3, Date.valueOf(t.getBorrowDate()));
            stmt.setDate(4, Date.valueOf(t.getDueDate()));
            stmt.setString(5, t.getStatus().name());

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet keys = stmt.getGeneratedKeys()) {
                    if (keys.next()) {
                        t.setId(keys.getInt(1));
                    }
                }
                return true;
            }
            return false;
        } catch (SQLException e) {
            throw new RuntimeException("Error recording transaction: " + e.getMessage(), e);
        }
    }

    public boolean markReturned(int transactionId, LocalDate returnDate) {
        String sql = "UPDATE transactions SET return_date = ?, status = 'RETURNED' "
                + "WHERE id = ? AND status = 'BORROWED'";

        try (PreparedStatement stmt = getConnection().prepareStatement(sql)) {
            stmt.setDate(1, Date.valueOf(returnDate));
            stmt.setInt(2, transactionId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Error marking transaction returned: " + e.getMessage(), e);
        }
    }

    public Transaction getTransactionById(int id) {
        String sql = SELECT_BASE + "WHERE t.id = ?";
        try (PreparedStatement stmt = getConnection().prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching transaction: " + e.getMessage(), e);
        }
        return null;
    }

    public List<Transaction> getAllTransactions() {
        List<Transaction> list = new ArrayList<>();
        String sql = SELECT_BASE + "ORDER BY t.borrow_date DESC";

        try (PreparedStatement stmt = getConnection().prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching transactions: " + e.getMessage(), e);
        }
        return list;
    }

    public List<Transaction> getActiveBorrowingsForMember(int memberId) {
        List<Transaction> list = new ArrayList<>();
        String sql = SELECT_BASE + "WHERE t.member_id = ? AND t.status = 'BORROWED' ORDER BY t.due_date";

        try (PreparedStatement stmt = getConnection().prepareStatement(sql)) {
            stmt.setInt(1, memberId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching member borrowings: " + e.getMessage(), e);
        }
        return list;
    }

    public List<Transaction> getOverdueTransactions() {
        List<Transaction> list = new ArrayList<>();
        String sql = SELECT_BASE + "WHERE t.status = 'BORROWED' AND t.due_date < CURDATE() ORDER BY t.due_date";

        try (PreparedStatement stmt = getConnection().prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching overdue transactions: " + e.getMessage(), e);
        }
        return list;
    }

    public List<Transaction> getActiveTransactions() {
        List<Transaction> list = new ArrayList<>();
        String sql = SELECT_BASE + "WHERE t.status = 'BORROWED' ORDER BY t.due_date";

        try (PreparedStatement stmt = getConnection().prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching active transactions: " + e.getMessage(), e);
        }
        return list;
    }

    private Transaction mapRow(ResultSet rs) throws SQLException {
        Transaction t = new Transaction();
        t.setId(rs.getInt("id"));
        t.setBookId(rs.getInt("book_id"));
        t.setMemberId(rs.getInt("member_id"));
        t.setBookTitle(rs.getString("book_title"));
        t.setMemberName(rs.getString("member_name"));
        t.setBorrowDate(rs.getDate("borrow_date").toLocalDate());
        t.setDueDate(rs.getDate("due_date").toLocalDate());

        Date returnDate = rs.getDate("return_date");
        t.setReturnDate(returnDate != null ? returnDate.toLocalDate() : null);
        t.setStatus(Transaction.Status.valueOf(rs.getString("status")));
        return t;
    }
}
