package com.library.service;

import com.library.dao.BookDAO;
import com.library.dao.MemberDAO;
import com.library.dao.TransactionDAO;
import com.library.model.Book;
import com.library.model.Member;
import com.library.model.Transaction;
import com.library.util.ValidationUtils;

import java.time.LocalDate;
import java.util.List;

/**
 * Central business-logic layer. The GUI talks to this class, never
 * directly to the DAOs, so that validation and cross-entity rules
 * (e.g. "can't delete a book that's currently on loan") live in one
 * place.
 */
public class LibraryService {

    private static final int DEFAULT_LOAN_PERIOD_DAYS = 14;
    private static final int MAX_BOOKS_PER_MEMBER = 5;

    private final BookDAO bookDAO = new BookDAO();
    private final MemberDAO memberDAO = new MemberDAO();
    private final TransactionDAO transactionDAO = new TransactionDAO();

    // ---------------------------------------------------------- Books

    public Book addBook(String isbn, String title, String author, String genre, int year, int quantity) {
        ValidationUtils.validateIsbn(isbn);
        ValidationUtils.requireNonBlank(title, "Title");
        ValidationUtils.requireNonBlank(author, "Author");
        ValidationUtils.validateYear(year);
        ValidationUtils.validatePositive(quantity, "Quantity");

        if (bookDAO.isbnExists(isbn)) {
            throw new IllegalArgumentException("A book with this ISBN already exists.");
        }

        Book book = new Book(isbn.trim(), title.trim(), author.trim(), genre, year, quantity);
        if (!bookDAO.addBook(book)) {
            throw new RuntimeException("Failed to add book.");
        }
        return book;
    }

    public void updateBook(Book book) {
        ValidationUtils.validateIsbn(book.getIsbn());
        ValidationUtils.requireNonBlank(book.getTitle(), "Title");
        ValidationUtils.requireNonBlank(book.getAuthor(), "Author");
        ValidationUtils.validateYear(book.getYear());
        ValidationUtils.validateNonNegative(book.getQuantity(), "Quantity");
        ValidationUtils.validateNonNegative(book.getAvailable(), "Available");

        if (book.getAvailable() > book.getQuantity()) {
            throw new IllegalArgumentException("Available copies cannot exceed total quantity.");
        }

        if (!bookDAO.updateBook(book)) {
            throw new RuntimeException("Failed to update book.");
        }
    }

    public void deleteBook(int bookId) {
        Book book = bookDAO.getBookById(bookId);
        if (book == null) {
            throw new IllegalArgumentException("Book not found.");
        }
        if (book.getAvailable() < book.getQuantity()) {
            throw new IllegalStateException("Cannot delete a book that has copies currently on loan.");
        }
        if (!bookDAO.deleteBook(bookId)) {
            throw new RuntimeException("Failed to delete book.");
        }
    }

    public List<Book> getAllBooks() {
        return bookDAO.getAllBooks();
    }

    public List<Book> searchBooks(String field, String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return bookDAO.getAllBooks();
        }
        if (field == null || field.equalsIgnoreCase("all")) {
            return bookDAO.searchBooks(keyword.trim());
        }
        return bookDAO.searchBooksByField(field, keyword.trim());
    }

    // ---------------------------------------------------------- Members

    public Member registerMember(String name, String email, String phone, String address) {
        ValidationUtils.requireNonBlank(name, "Name");
        ValidationUtils.validateEmail(email);
        ValidationUtils.validatePhone(phone);

        if (memberDAO.emailExists(email)) {
            throw new IllegalArgumentException("A member with this email already exists.");
        }

        Member member = new Member(name.trim(), email.trim(), phone, address);
        if (!memberDAO.addMember(member)) {
            throw new RuntimeException("Failed to register member.");
        }
        return member;
    }

    public void updateMember(Member member) {
        ValidationUtils.requireNonBlank(member.getName(), "Name");
        ValidationUtils.validateEmail(member.getEmail());
        ValidationUtils.validatePhone(member.getPhone());

        if (!memberDAO.updateMember(member)) {
            throw new RuntimeException("Failed to update member.");
        }
    }

    public void deleteMember(int memberId) {
        List<Transaction> active = transactionDAO.getActiveBorrowingsForMember(memberId);
        if (!active.isEmpty()) {
            throw new IllegalStateException("Cannot delete a member with active borrowings.");
        }
        if (!memberDAO.deleteMember(memberId)) {
            throw new RuntimeException("Failed to delete member.");
        }
    }

    public List<Member> getAllMembers() {
        return memberDAO.getAllMembers();
    }

    public List<Member> searchMembers(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return memberDAO.getAllMembers();
        }
        return memberDAO.searchMembers(keyword.trim());
    }

    // ---------------------------------------------------------- Borrow / Return

    /**
     * Borrows a book on behalf of a member, enforcing availability and
     * the per-member borrowing cap, then decrements the book's
     * available count.
     */
    public Transaction borrowBook(int bookId, int memberId) {
        Book book = bookDAO.getBookById(bookId);
        if (book == null) {
            throw new IllegalArgumentException("Book not found.");
        }
        if (book.getAvailable() <= 0) {
            throw new IllegalStateException("No copies of \"" + book.getTitle() + "\" are currently available.");
        }

        Member member = memberDAO.getMemberById(memberId);
        if (member == null) {
            throw new IllegalArgumentException("Member not found.");
        }
        if (member.getStatus() == Member.Status.INACTIVE) {
            throw new IllegalStateException("Member account is inactive and cannot borrow books.");
        }

        List<Transaction> active = transactionDAO.getActiveBorrowingsForMember(memberId);
        if (active.size() >= MAX_BOOKS_PER_MEMBER) {
            throw new IllegalStateException(
                    "Member has reached the maximum of " + MAX_BOOKS_PER_MEMBER + " borrowed books.");
        }

        LocalDate today = LocalDate.now();
        Transaction t = new Transaction(bookId, memberId, today, today.plusDays(DEFAULT_LOAN_PERIOD_DAYS));

        if (!transactionDAO.addTransaction(t)) {
            throw new RuntimeException("Failed to record borrow transaction.");
        }
        if (!bookDAO.adjustAvailability(bookId, -1)) {
            throw new RuntimeException("Failed to update book availability.");
        }
        return t;
    }

    /**
     * Returns a previously borrowed book, marking the transaction
     * complete and restoring the book's available count.
     */
    public void returnBook(int transactionId) {
        Transaction t = transactionDAO.getTransactionById(transactionId);
        if (t == null) {
            throw new IllegalArgumentException("Transaction not found.");
        }
        if (t.getStatus() == Transaction.Status.RETURNED) {
            throw new IllegalStateException("This book has already been returned.");
        }

        if (!transactionDAO.markReturned(transactionId, LocalDate.now())) {
            throw new RuntimeException("Failed to mark transaction as returned.");
        }
        if (!bookDAO.adjustAvailability(t.getBookId(), 1)) {
            throw new RuntimeException("Failed to update book availability.");
        }
    }

    public List<Transaction> getActiveTransactions() {
        return transactionDAO.getActiveTransactions();
    }

    public List<Transaction> getAllTransactions() {
        return transactionDAO.getAllTransactions();
    }

    public List<Transaction> getOverdueTransactions() {
        return transactionDAO.getOverdueTransactions();
    }

    // ---------------------------------------------------------- Dashboard stats

    public int getTotalBookCount() {
        return bookDAO.getAllBooks().stream().mapToInt(Book::getQuantity).sum();
    }

    public int getAvailableBookCount() {
        return bookDAO.getAllBooks().stream().mapToInt(Book::getAvailable).sum();
    }

    public int getTotalMemberCount() {
        return memberDAO.getAllMembers().size();
    }

    public int getActiveBorrowingCount() {
        return transactionDAO.getActiveTransactions().size();
    }

    public int getOverdueCount() {
        return transactionDAO.getOverdueTransactions().size();
    }
}
