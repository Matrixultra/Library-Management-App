package com.library.model;

import java.time.LocalDateTime;

/**
 * Represents a registered library member who may borrow books.
 */
public class Member {

    public enum Status {
        ACTIVE, INACTIVE
    }

    private int id;
    private String name;
    private String email;
    private String phone;
    private String address;
    private Status status;
    private LocalDateTime joinedAt;

    public Member() {
        this.status = Status.ACTIVE;
    }

    public Member(String name, String email, String phone, String address) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.status = Status.ACTIVE;
    }

    public Member(int id, String name, String email, String phone, String address,
                  Status status, LocalDateTime joinedAt) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.status = status;
        this.joinedAt = joinedAt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public LocalDateTime getJoinedAt() {
        return joinedAt;
    }

    public void setJoinedAt(LocalDateTime joinedAt) {
        this.joinedAt = joinedAt;
    }

    @Override
    public String toString() {
        return name + " (" + email + ")";
    }
}
