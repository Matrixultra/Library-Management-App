package com.library.util;

import java.time.Year;
import java.util.regex.Pattern;

/**
 * Stateless helpers for validating user input before it reaches the
 * database layer. Each method either returns a boolean or throws
 * {@link IllegalArgumentException} with a message suitable for
 * displaying directly to the user.
 */
public final class ValidationUtils {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    private static final Pattern ISBN_PATTERN =
            Pattern.compile("^(97[89])?[-0-9Xx]{9,17}$");

    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^[0-9+\\-\\s]{7,20}$");

    private ValidationUtils() {
    }

    public static void requireNonBlank(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be empty.");
        }
    }

    public static void validateIsbn(String isbn) {
        requireNonBlank(isbn, "ISBN");
        if (!ISBN_PATTERN.matcher(isbn.trim()).matches()) {
            throw new IllegalArgumentException("ISBN format is invalid.");
        }
    }

    public static void validateEmail(String email) {
        requireNonBlank(email, "Email");
        if (!EMAIL_PATTERN.matcher(email.trim()).matches()) {
            throw new IllegalArgumentException("Email format is invalid.");
        }
    }

    public static void validatePhone(String phone) {
        if (phone == null || phone.trim().isEmpty()) {
            return; // phone is optional
        }
        if (!PHONE_PATTERN.matcher(phone.trim()).matches()) {
            throw new IllegalArgumentException("Phone number format is invalid.");
        }
    }

    public static void validateYear(int year) {
        int currentYear = Year.now().getValue();
        if (year < 1450 || year > currentYear + 1) {
            throw new IllegalArgumentException(
                    "Year must be between 1450 and " + (currentYear + 1) + ".");
        }
    }

    public static void validatePositive(int value, String fieldName) {
        if (value <= 0) {
            throw new IllegalArgumentException(fieldName + " must be greater than zero.");
        }
    }

    public static void validateNonNegative(int value, String fieldName) {
        if (value < 0) {
            throw new IllegalArgumentException(fieldName + " cannot be negative.");
        }
    }
}
