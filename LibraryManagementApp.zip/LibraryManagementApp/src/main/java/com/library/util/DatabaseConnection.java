package com.library.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton wrapper around a single JDBC {@link Connection} to the
 * library_db MySQL database.
 *
 * Connection details are read from system properties if present
 * (db.url, db.user, db.password) so they can be overridden without
 * recompiling, falling back to sensible local defaults otherwise.
 */
public final class DatabaseConnection {

    private static DatabaseConnection instance;
    private Connection connection;

    private static final String DEFAULT_URL =
            "jdbc:mysql://localhost:3306/library_db?useSSL=false&serverTimezone=UTC";
    private static final String DEFAULT_USER = "root";
    private static final String DEFAULT_PASSWORD = "password";

    private DatabaseConnection() {
        String url = System.getProperty("db.url", DEFAULT_URL);
        String user = System.getProperty("db.user", DEFAULT_USER);
        String password = System.getProperty("db.password", DEFAULT_PASSWORD);

        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            throw new IllegalStateException(
                    "Could not connect to database at " + url
                            + ". Check that MySQL is running and schema.sql has been applied.", e);
        }
    }

    public static synchronized DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }

    public Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                instance = new DatabaseConnection();
                return instance.connection;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Error checking database connection state", e);
        }
        return connection;
    }

    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing database connection: " + e.getMessage());
        }
    }
}
