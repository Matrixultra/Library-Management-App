package com.library.gui;

import com.library.model.Transaction;
import com.library.service.LibraryService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Landing tab: at-a-glance library statistics and an overdue-items list.
 */
public class DashboardView extends BorderPane {

    private final LibraryService service;
    private final GridPane statsGrid = new GridPane();
    private final VBox overdueBox = new VBox(6);

    public DashboardView(LibraryService service) {
        this.service = service;

        setPadding(new Insets(0, 0, 0, 0));

        Label title = new Label("Library Dashboard");
        title.getStyleClass().add("app-title");
        VBox header = new VBox(title);
        header.setPadding(new Insets(0, 0, 16, 0));
        setTop(header);

        statsGrid.setHgap(14);
        statsGrid.setVgap(14);

        VBox content = new VBox(20, statsGrid, buildOverdueSection());
        setCenter(content);

        refresh();
    }

    /** Re-reads stats and overdue list from the database. Call after any mutation. */
    public void refresh() {
        statsGrid.getChildren().clear();

        int totalBooks = service.getTotalBookCount();
        int available = service.getAvailableBookCount();
        int members = service.getTotalMemberCount();
        int activeBorrowings = service.getActiveBorrowingCount();
        int overdue = service.getOverdueCount();

        statsGrid.add(statCard("Total Books", String.valueOf(totalBooks), "-fx-ink"), 0, 0);
        statsGrid.add(statCard("Available Books", String.valueOf(available), "-fx-good"), 1, 0);
        statsGrid.add(statCard("Total Members", String.valueOf(members), "-fx-accent"), 2, 0);
        statsGrid.add(statCard("Active Borrowings", String.valueOf(activeBorrowings), "-fx-ink"), 0, 1);
        statsGrid.add(statCard("Overdue Books", String.valueOf(overdue), "-fx-bad"), 1, 1);

        for (Node n : statsGrid.getChildren()) {
            GridPane.setHgrow(n, Priority.ALWAYS);
        }

        refreshOverdueList();
    }

    private VBox statCard(String titleText, String value, String colorVar) {
        Label valueLabel = new Label(value);
        valueLabel.getStyleClass().add("stat-value");
        valueLabel.setStyle("-fx-text-fill: " + colorVar + ";");

        Label titleLabel = new Label(titleText);
        titleLabel.getStyleClass().add("stat-title");

        VBox card = new VBox(6, valueLabel, titleLabel);
        card.getStyleClass().add("stat-card");
        card.setPrefWidth(220);
        return card;
    }

    private VBox buildOverdueSection() {
        Label heading = new Label("Overdue Books");
        heading.getStyleClass().add("section-title");

        VBox section = new VBox(10, heading, overdueBox);
        return section;
    }

    private void refreshOverdueList() {
        overdueBox.getChildren().clear();
        List<Transaction> overdue = service.getOverdueTransactions();

        if (overdue.isEmpty()) {
            Label none = new Label("No overdue books. Nice work.");
            none.getStyleClass().add("subtle-label");
            overdueBox.getChildren().add(none);
            return;
        }

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MMM d, yyyy");

        for (Transaction t : overdue) {
            HBox row = new HBox(12);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(8));
            row.getStyleClass().add("stat-card");

            Label info = new Label(t.getBookTitle() + " — borrowed by " + t.getMemberName());
            Label dueInfo = new Label("Due " + t.getDueDate().format(fmt)
                    + " (" + t.daysOverdue() + " day" + (t.daysOverdue() == 1 ? "" : "s") + " overdue)");
            dueInfo.getStyleClass().add("tag-overdue");

            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            row.getChildren().addAll(info, spacer, dueInfo);
            overdueBox.getChildren().add(row);
        }
    }
}
