package com.library.gui;

import com.library.service.LibraryService;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * Root JavaFX application: builds the tabbed shell (Dashboard, Books,
 * Members, Transactions) and wires each view so that a change in one
 * tab (e.g. borrowing a book) refreshes the others that depend on it.
 */
public class MainApp extends Application {

    private LibraryService service;
    private DashboardView dashboardView;
    private BooksView booksView;
    private MembersView membersView;
    private TransactionsView transactionsView;

    @Override
    public void start(Stage stage) {
        try {
            service = new LibraryService();
        } catch (Exception e) {
            showFatalError("Could not start the application.\n\n" + e.getMessage());
            return;
        }

        Runnable refreshAll = this::refreshAll;

        dashboardView = new DashboardView(service);
        booksView = new BooksView(service, refreshAll);
        membersView = new MembersView(service, refreshAll);
        transactionsView = new TransactionsView(service, refreshAll);

        TabPane tabs = new TabPane();
        tabs.getTabs().addAll(
                tab("Dashboard", dashboardView),
                tab("Books", booksView),
                tab("Members", membersView),
                tab("Transactions", transactionsView)
        );
        tabs.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            // Dashboard stats can go stale while other tabs are used; refresh on entry.
            if (newTab != null && "Dashboard".equals(newTab.getText())) {
                dashboardView.refresh();
            }
        });

        BorderPane root = new BorderPane(tabs);
        root.setPadding(new Insets(0));

        Scene scene = new Scene(root, 1080, 720);
        scene.getStylesheets().add(getClass().getResource("app.css").toExternalForm());

        stage.setTitle("Library Management System");
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    private Tab tab(String title, javafx.scene.Node content) {
        Tab t = new Tab(title, content);
        t.setClosable(false);
        return t;
    }

    private void refreshAll() {
        dashboardView.refresh();
        booksView.refresh();
        membersView.refresh();
        transactionsView.refresh();
    }

    private void showFatalError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message, ButtonType.OK);
        alert.setTitle("Startup Error");
        alert.setHeaderText("Database connection failed");
        alert.showAndWait();
    }
}
