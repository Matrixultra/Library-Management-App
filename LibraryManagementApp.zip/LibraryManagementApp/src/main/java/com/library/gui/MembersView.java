package com.library.gui;

import com.library.model.Member;
import com.library.service.LibraryService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.Optional;

/**
 * Members tab: search, list, register, edit, and remove members.
 */
public class MembersView extends BorderPane {

    private final LibraryService service;
    private final Runnable onDataChanged;

    private final TableView<Member> table = new TableView<>();
    private final TextField searchField = new TextField();

    public MembersView(LibraryService service, Runnable onDataChanged) {
        this.service = service;
        this.onDataChanged = onDataChanged;

        setTop(buildToolbar());
        setCenter(buildTable());

        refresh();
    }

    private VBox buildToolbar() {
        Button addBtn = new Button("Register Member");
        addBtn.getStyleClass().add("button-primary");
        addBtn.setOnAction(e -> openMemberForm(null));

        Button editBtn = new Button("Edit Selected");
        editBtn.setOnAction(e -> {
            Member selected = table.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showInfo("Select a member first.");
                return;
            }
            openMemberForm(selected);
        });

        Button deleteBtn = new Button("Remove Selected");
        deleteBtn.getStyleClass().add("button-danger");
        deleteBtn.setOnAction(e -> {
            Member selected = table.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showInfo("Select a member first.");
                return;
            }
            confirmAndDelete(selected);
        });

        searchField.setPromptText("Search by name or email...");
        searchField.setPrefWidth(280);
        searchField.textProperty().addListener((obs, old, val) -> performSearch());

        HBox toolbar = new HBox(10, addBtn, editBtn, deleteBtn,
                spacer(), new Label("Search:"), searchField);
        toolbar.getStyleClass().add("toolbar-panel");
        toolbar.setAlignment(Pos.CENTER_LEFT);

        return new VBox(toolbar);
    }

    private TableView<Member> buildTable() {
        TableColumn<Member, Number> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(50);

        TableColumn<Member, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setPrefWidth(180);

        TableColumn<Member, String> emailCol = new TableColumn<>("Email");
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        emailCol.setPrefWidth(200);

        TableColumn<Member, String> phoneCol = new TableColumn<>("Phone");
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));

        TableColumn<Member, String> addressCol = new TableColumn<>("Address");
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        addressCol.setPrefWidth(200);

        TableColumn<Member, Member.Status> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        table.getColumns().addAll(idCol, nameCol, emailCol, phoneCol, addressCol, statusCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        VBox.setVgrow(table, Priority.ALWAYS);
        return table;
    }

    private void performSearch() {
        try {
            ObservableList<Member> results =
                    FXCollections.observableArrayList(service.searchMembers(searchField.getText()));
            table.setItems(results);
        } catch (Exception ex) {
            showError(ex.getMessage());
        }
    }

    public void refresh() {
        searchField.clear();
        table.setItems(FXCollections.observableArrayList(service.getAllMembers()));
    }

    private void openMemberForm(Member existing) {
        boolean isEdit = existing != null;
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle(isEdit ? "Edit Member" : "Register New Member");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        TextField nameField = new TextField(isEdit ? existing.getName() : "");
        TextField emailField = new TextField(isEdit ? existing.getEmail() : "");
        TextField phoneField = new TextField(isEdit ? existing.getPhone() : "");
        TextField addressField = new TextField(isEdit ? existing.getAddress() : "");
        ComboBox<Member.Status> statusBox = new ComboBox<>(
                FXCollections.observableArrayList(Member.Status.values()));
        statusBox.setValue(isEdit ? existing.getStatus() : Member.Status.ACTIVE);

        GridPaneForm form = new GridPaneForm();
        form.addRow("Name", nameField);
        form.addRow("Email", emailField);
        form.addRow("Phone", phoneField);
        form.addRow("Address", addressField);
        if (isEdit) {
            form.addRow("Status", statusBox);
        }

        dialog.getDialogPane().setContent(form.getPane());

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                if (isEdit) {
                    existing.setName(nameField.getText().trim());
                    existing.setEmail(emailField.getText().trim());
                    existing.setPhone(phoneField.getText().trim());
                    existing.setAddress(addressField.getText().trim());
                    existing.setStatus(statusBox.getValue());
                    service.updateMember(existing);
                } else {
                    service.registerMember(nameField.getText().trim(), emailField.getText().trim(),
                            phoneField.getText().trim(), addressField.getText().trim());
                }
                refresh();
                onDataChanged.run();
            } catch (Exception ex) {
                showError(ex.getMessage());
            }
        }
    }

    private void confirmAndDelete(Member member) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Remove member \"" + member.getName() + "\"? This cannot be undone.",
                ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirm Removal");
        confirm.setHeaderText(null);

        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.YES) {
            try {
                service.deleteMember(member.getId());
                refresh();
                onDataChanged.run();
            } catch (Exception ex) {
                showError(ex.getMessage());
            }
        }
    }

    private Region spacer() {
        Region r = new Region();
        HBox.setHgrow(r, Priority.ALWAYS);
        return r;
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message, ButtonType.OK);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
        alert.setTitle("Notice");
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
