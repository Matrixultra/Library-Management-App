package com.library.gui;

import com.library.model.Book;
import com.library.model.Member;
import com.library.model.Transaction;
import com.library.service.LibraryService;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;

import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * Transactions tab: borrow a book for a member, return a borrowed
 * book, and view the current list of active loans (with overdue
 * items flagged).
 */
public class TransactionsView extends BorderPane {

    private final LibraryService service;
    private final Runnable onDataChanged;
    private final TableView<Transaction> table = new TableView<>();

    public TransactionsView(LibraryService service, Runnable onDataChanged) {
        this.service = service;
        this.onDataChanged = onDataChanged;

        setTop(buildToolbar());
        setCenter(buildTable());

        refresh();
    }

    private VBox buildToolbar() {
        Button borrowBtn = new Button("Borrow Book");
        borrowBtn.getStyleClass().add("button-primary");
        borrowBtn.setOnAction(e -> openBorrowDialog());

        Button returnBtn = new Button("Return Selected");
        returnBtn.setOnAction(e -> {
            Transaction selected = table.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showInfo("Select an active loan to return.");
                return;
            }
            if (selected.getStatus() == Transaction.Status.RETURNED) {
                showInfo("This loan has already been returned.");
                return;
            }
            try {
                service.returnBook(selected.getId());
                refresh();
                onDataChanged.run();
            } catch (Exception ex) {
                showError(ex.getMessage());
            }
        });

        Button refreshBtn = new Button("Refresh");
        refreshBtn.setOnAction(e -> refresh());

        HBox toolbar = new HBox(10, borrowBtn, returnBtn, spacer(), refreshBtn);
        toolbar.getStyleClass().add("toolbar-panel");
        toolbar.setAlignment(Pos.CENTER_LEFT);

        return new VBox(toolbar);
    }

    private TableView<Transaction> buildTable() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MMM d, yyyy");

        TableColumn<Transaction, String> bookCol = new TableColumn<>("Book");
        bookCol.setCellValueFactory(new PropertyValueFactory<>("bookTitle"));
        bookCol.setPrefWidth(220);

        TableColumn<Transaction, String> memberCol = new TableColumn<>("Member");
        memberCol.setCellValueFactory(new PropertyValueFactory<>("memberName"));
        memberCol.setPrefWidth(160);

        TableColumn<Transaction, java.time.LocalDate> borrowCol = new TableColumn<>("Borrowed");
        borrowCol.setCellValueFactory(new PropertyValueFactory<>("borrowDate"));
        borrowCol.setCellFactory(col -> dateCell(fmt));

        TableColumn<Transaction, java.time.LocalDate> dueCol = new TableColumn<>("Due");
        dueCol.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
        dueCol.setCellFactory(col -> dateCell(fmt));

        TableColumn<Transaction, java.time.LocalDate> returnCol = new TableColumn<>("Returned");
        returnCol.setCellValueFactory(new PropertyValueFactory<>("returnDate"));
        returnCol.setCellFactory(col -> dateCell(fmt));

        TableColumn<Transaction, Transaction.Status> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(Transaction.Status status, boolean empty) {
                super.updateItem(status, empty);
                if (empty || status == null) {
                    setText(null);
                    getStyleClass().removeAll("tag-overdue", "tag-active");
                    return;
                }
                Transaction t = getTableRow().getItem();
                if (t != null && t.isOverdue()) {
                    setText("OVERDUE");
                    getStyleClass().add("tag-overdue");
                } else {
                    setText(status.name());
                    getStyleClass().removeAll("tag-overdue");
                    if (status == Transaction.Status.BORROWED) {
                        getStyleClass().add("tag-active");
                    }
                }
            }
        });

        table.getColumns().addAll(bookCol, memberCol, borrowCol, dueCol, returnCol, statusCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        VBox.setVgrow(table, Priority.ALWAYS);
        return table;
    }

    private TableCell<Transaction, java.time.LocalDate> dateCell(DateTimeFormatter fmt) {
        return new TableCell<>() {
            @Override
            protected void updateItem(java.time.LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setText(empty || date == null ? "" : date.format(fmt));
            }
        };
    }

    public void refresh() {
        table.setItems(FXCollections.observableArrayList(service.getAllTransactions()));
    }

    private void openBorrowDialog() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Borrow Book");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        ComboBox<Book> bookBox = new ComboBox<>(
                FXCollections.observableArrayList(service.getAllBooks()));
        bookBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(Book b) {
                return b == null ? "" : b.getTitle() + " (" + b.getAvailable() + " available)";
            }

            @Override
            public Book fromString(String s) {
                return null;
            }
        });

        ComboBox<Member> memberBox = new ComboBox<>(
                FXCollections.observableArrayList(service.getAllMembers()));
        memberBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(Member m) {
                return m == null ? "" : m.getName() + " (" + m.getStatus() + ")";
            }

            @Override
            public Member fromString(String s) {
                return null;
            }
        });

        GridPaneForm form = new GridPaneForm();
        form.addRow("Book", bookBox);
        form.addRow("Member", memberBox);
        dialog.getDialogPane().setContent(form.getPane());

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Book book = bookBox.getValue();
            Member member = memberBox.getValue();
            if (book == null || member == null) {
                showError("Please select both a book and a member.");
                return;
            }
            try {
                service.borrowBook(book.getId(), member.getId());
                refresh();
                onDataChanged.run();
            } catch (Exception ex) {
                showError(ex.getMessage());
            }
        }
    }

    private Region spacer() {
        Region r = new Region();
        HBox.setHgrow(r, Priority.ALWAYS);
        return r;
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message, ButtonType.OK);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
        alert.setTitle("Notice");
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
