package com.library.gui;

import com.library.model.Book;
import com.library.service.LibraryService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.Optional;

/**
 * Books tab: search, list, add, edit, and delete books.
 */
public class BooksView extends BorderPane {

    private final LibraryService service;
    private final Runnable onDataChanged;

    private final TableView<Book> table = new TableView<>();
    private final TextField searchField = new TextField();
    private final ComboBox<String> searchScope = new ComboBox<>(
            FXCollections.observableArrayList("All Fields", "Title", "Author", "ISBN", "Genre"));

    public BooksView(LibraryService service, Runnable onDataChanged) {
        this.service = service;
        this.onDataChanged = onDataChanged;

        setTop(buildToolbar());
        setCenter(buildTable());

        refresh();
    }

    private VBox buildToolbar() {
        Button addBtn = new Button("Add Book");
        addBtn.getStyleClass().add("button-primary");
        addBtn.setOnAction(e -> openBookForm(null));

        Button editBtn = new Button("Edit Selected");
        editBtn.setOnAction(e -> {
            Book selected = table.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showInfo("Select a book first.");
                return;
            }
            openBookForm(selected);
        });

        Button deleteBtn = new Button("Delete Selected");
        deleteBtn.getStyleClass().add("button-danger");
        deleteBtn.setOnAction(e -> {
            Book selected = table.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showInfo("Select a book first.");
                return;
            }
            confirmAndDelete(selected);
        });

        searchScope.getSelectionModel().selectFirst();
        searchField.setPromptText("Search books...");
        searchField.setPrefWidth(260);
        searchField.textProperty().addListener((obs, old, val) -> performSearch());
        searchScope.valueProperty().addListener((obs, old, val) -> performSearch());

        HBox toolbar = new HBox(10, addBtn, editBtn, deleteBtn,
                spacer(), new Label("Search:"), searchField, searchScope);
        toolbar.getStyleClass().add("toolbar-panel");
        toolbar.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        VBox top = new VBox(toolbar);
        return top;
    }

    @SuppressWarnings("unchecked")
    private TableView<Book> buildTable() {
        TableColumn<Book, String> isbnCol = new TableColumn<>("ISBN");
        isbnCol.setCellValueFactory(new PropertyValueFactory<>("isbn"));

        TableColumn<Book, String> titleCol = new TableColumn<>("Title");
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        titleCol.setPrefWidth(220);

        TableColumn<Book, String> authorCol = new TableColumn<>("Author");
        authorCol.setCellValueFactory(new PropertyValueFactory<>("author"));
        authorCol.setPrefWidth(160);

        TableColumn<Book, String> genreCol = new TableColumn<>("Genre");
        genreCol.setCellValueFactory(new PropertyValueFactory<>("genre"));

        TableColumn<Book, Number> yearCol = new TableColumn<>("Year");
        yearCol.setCellValueFactory(new PropertyValueFactory<>("year"));

        TableColumn<Book, Number> qtyCol = new TableColumn<>("Quantity");
        qtyCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));

        TableColumn<Book, Number> availCol = new TableColumn<>("Available");
        availCol.setCellValueFactory(new PropertyValueFactory<>("available"));

        table.getColumns().addAll(isbnCol, titleCol, authorCol, genreCol, yearCol, qtyCol, availCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        VBox.setVgrow(table, javafx.scene.layout.Priority.ALWAYS);
        return table;
    }

    private void performSearch() {
        String keyword = searchField.getText();
        String scope = searchScope.getValue();
        String field = (scope == null || scope.equals("All Fields")) ? "all" : scope;

        try {
            ObservableList<Book> results = FXCollections.observableArrayList(service.searchBooks(field, keyword));
            table.setItems(results);
        } catch (Exception ex) {
            showError(ex.getMessage());
        }
    }

    /** Re-loads the full book list and clears any active search. */
    public void refresh() {
        searchField.clear();
        table.setItems(FXCollections.observableArrayList(service.getAllBooks()));
    }

    private void openBookForm(Book existing) {
        boolean isEdit = existing != null;
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle(isEdit ? "Edit Book" : "Add New Book");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        TextField isbnField = new TextField(isEdit ? existing.getIsbn() : "");
        TextField titleField = new TextField(isEdit ? existing.getTitle() : "");
        TextField authorField = new TextField(isEdit ? existing.getAuthor() : "");
        TextField genreField = new TextField(isEdit ? existing.getGenre() : "");
        TextField yearField = new TextField(isEdit ? String.valueOf(existing.getYear()) : "");
        TextField quantityField = new TextField(isEdit ? String.valueOf(existing.getQuantity()) : "");

        GridPaneForm form = new GridPaneForm();
        form.addRow("ISBN", isbnField);
        form.addRow("Title", titleField);
        form.addRow("Author", authorField);
        form.addRow("Genre", genreField);
        form.addRow("Year", yearField);
        form.addRow("Quantity" + (isEdit ? " (total copies)" : ""), quantityField);

        dialog.getDialogPane().setContent(form.getPane());

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                int year = Integer.parseInt(yearField.getText().trim());
                int quantity = Integer.parseInt(quantityField.getText().trim());

                if (isEdit) {
                    int delta = quantity - existing.getQuantity();
                    existing.setIsbn(isbnField.getText().trim());
                    existing.setTitle(titleField.getText().trim());
                    existing.setAuthor(authorField.getText().trim());
                    existing.setGenre(genreField.getText().trim());
                    existing.setYear(year);
                    existing.setQuantity(quantity);
                    existing.setAvailable(Math.max(0, existing.getAvailable() + delta));
                    service.updateBook(existing);
                } else {
                    service.addBook(isbnField.getText().trim(), titleField.getText().trim(),
                            authorField.getText().trim(), genreField.getText().trim(), year, quantity);
                }
                refresh();
                onDataChanged.run();
            } catch (NumberFormatException nfe) {
                showError("Year and Quantity must be valid numbers.");
            } catch (Exception ex) {
                showError(ex.getMessage());
            }
        }
    }

    private void confirmAndDelete(Book book) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Delete \"" + book.getTitle() + "\"? This cannot be undone.",
                ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirm Delete");
        confirm.setHeaderText(null);

        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.YES) {
            try {
                service.deleteBook(book.getId());
                refresh();
                onDataChanged.run();
            } catch (Exception ex) {
                showError(ex.getMessage());
            }
        }
    }

    private Region spacer() {
        Region r = new Region();
        HBox.setHgrow(r, javafx.scene.layout.Priority.ALWAYS);
        return r;
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message, ButtonType.OK);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
        alert.setTitle("Notice");
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
