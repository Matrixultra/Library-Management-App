package com.library.gui;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

/**
 * Tiny helper for laying out label/field pairs in dialog forms,
 * used by both the Add/Edit Book and Add/Edit Member dialogs so
 * each one stays focused on its own fields rather than repeating
 * GridPane boilerplate.
 */
public class GridPaneForm {

    private final GridPane grid = new GridPane();
    private int row = 0;

    public GridPaneForm() {
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(15));
    }

    public void addRow(String labelText, Node field) {
        Label label = new Label(labelText + ":");
        grid.add(label, 0, row);
        grid.add(field, 1, row);
        if (field instanceof javafx.scene.control.Control control) {
            control.setPrefWidth(240);
        }
        row++;
    }

    public GridPane getPane() {
        return grid;
    }
}
